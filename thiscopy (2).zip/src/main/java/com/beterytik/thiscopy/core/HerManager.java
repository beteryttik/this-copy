package com.beterytik.thiscopy.core;

import com.beterytik.thiscopy.ModConfig;
import com.beterytik.thiscopy.ModRegistry;
import com.beterytik.thiscopy.entity.HerState;
import com.beterytik.thiscopy.entity.SheEntity;
import com.beterytik.thiscopy.phase.*;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.List;
import java.util.Optional;

public class HerManager {
    private static final PhaseStrategy[] STRATEGIES = {
            null,
            new ShadowPhase(), new MirrorPhase(), new EchoPhase(),
            new GlitchPhase(), new HuntPhase(), new AllyPhase()
    };

    private final ServerWorld world;
    private final HerState state;
    private long worldTicks = 0;

    public HerManager(ServerWorld world) {
        this.world = world;
        this.state = HerState.get(world);
    }

    public static HerManager get(ServerWorld world) {
        return new HerManager(world);
    }

    public ServerWorld world() { return world; }
    public long worldTicks() { return worldTicks; }
    public HerState state() { return state; }

    public PhaseStrategy phase() {
        return STRATEGIES[state.phaseId()];
    }

    public int phaseTicksLeft() {
        PhaseStrategy p = phase();
        if (p == null) return 0;
        return p.durationTicks() - state.phaseTicks();
    }

    public ServerPlayerEntity victim() {
        if (state.victim() == null) return null;
        return world.getServer().getPlayerManager().getPlayer(state.victim());
    }

    public BlockPos victimPos() {
        ServerPlayerEntity v = victim();
        if (v == null) return null;
        return v.getBlockPos();
    }

    public EchoChat echo() { return EchoChat.get(world); }
    public WhisperGenerator whisper() { return new WhisperGenerator(); }

    public Optional<SheEntity> entity() {
        return world.getEntitiesByClass(SheEntity.class, world.getWorldBorder().getShapeEachChunkBox(),
                (e) -> true).stream().findFirst();
    }

    public void tick() {
        worldTicks++;
        PhaseStrategy p = phase();
        if (p == null) {
            selectVictimIfNeeded();
            return;
        }
        p.tick(this);
        state.setPhaseTicks(state.phaseTicks() + 1);
        MovementBuffer.sample(victim());

        if (state.phaseTicks() >= p.durationTicks() && p.id() < 5) {
            advance();
        }
        state.markDirty();
    }

    public void selectVictimIfNeeded() {
        if (state.victim() != null) return;
        List<ServerPlayerEntity> players = world.getPlayers();
        if (players.isEmpty()) return;
        ServerPlayerEntity chosen = VictimSelector.choose(players, state.victim());
        state.setVictim(chosen.getUuid());
        state.setPhaseTicks(0);
        state.setPhaseId(1);
        announce(chosen, "shadow.begin");
        MovementBuffer.init(chosen);
        state.markDirty();
    }

    public void advance() {
        int next = Math.min(5, state.phaseId() + 1);
        state.setPhaseId(next);
        state.setPhaseTicks(0);
        PhaseStrategy p = phase();
        if (p != null && victim() != null) {
            announce(victim(), "phase." + next);
        }
        state.markDirty();
    }

    public void setPhase(int id) {
        state.setPhaseId(id);
        state.setPhaseTicks(0);
        state.markDirty();
    }

    public void spawnSheNear(BlockPos pos) {
        if (entity().isPresent()) return;
        SheEntity she = ModRegistry.SHE.create(world, SpawnReason.EVENT);
        if (she == null) return;
        she.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0.0F, 0.0F);
        world.spawnEntity(she);
    }

    public void announce(ServerPlayerEntity p, String key) {
        if (p != null) {
            p.sendMessage(Text.translatable("message.thiscopy." + key));
        }
    }
}
