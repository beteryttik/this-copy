package com.beterytik.thiscopy.core;

import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Эхо-чат: возвращает твои фразы позже, немного «испорченные». */
public class EchoChat {
    private static final Map<UUID, Deque<String>> HISTORY = new ConcurrentHashMap<>();

    public static void registerHook() {
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            HISTORY.computeIfAbsent(sender.getUuid(), k -> new ArrayDeque<>())
                    .addLast(message.getSignedContent().plain());
            Deque<String> d = HISTORY.get(sender.getUuid());
            while (d.size() > 20) d.removeFirst();
        });
    }

    public static EchoChat get(ServerWorld world) {
        return new EchoChat(world);
    }

    private final ServerWorld world;

    private EchoChat(ServerWorld world) {
        this.world = world;
    }

    public void echoOnce() {
        for (ServerPlayerEntity p : world.getPlayers()) {
            Deque<String> d = HISTORY.get(p.getUuid());
            if (d == null || d.isEmpty()) continue;
            String[] arr = d.toArray(new String[0]);
            String older = arr[(int) (Math.random() * arr.length)];
            String corrupted = corrupt(older);
            p.sendMessage(Text.literal("<???> " + corrupted).formatted(Formatting.DARK_GRAY));
        }
    }

    /** Порча: случайные символы заменяются, регистр дрожит. */
    private String corrupt(String s) {
        char[] c = s.toCharArray();
        for (int i = 0; i < c.length; i++) {
            if (Math.random() < 0.12 && Character.isLetter(c[i])) {
                c[i] = Math.random() < 0.5
                        ? Character.toUpperCase(c[i])
                        : Character.toLowerCase(c[i]);
            }
        }
        return new String(c);
    }
}
