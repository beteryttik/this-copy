package com.beterytik.thiscopy.core;

import java.util.List;
import java.util.Random;

public class PhraseBank {
    private static final Random RNG = new Random();

    private static final List<String> SHADOW = List.of(
            "ты видел, кто стоял за тобой?", "это не ты прошёл мимо",
            "зеркало запомнило", "она уже внутри чата",
            "не отвечай", "посмотри в стекло");
    private static final List<String> ECHO = List.of(
            "это было не эхо", "я слышу твой голос", "повтори за мной",
            "ты уже говорил это", "кто повторяет?");
    private static final List<String> HUNT = List.of(
            "твоё имя мне подходит", "почти я", "осталось чуть-чуть",
            "тени кончаются", "не храни ничего в сундуке");

    public static String shadow() { return pick(SHADOW); }
    public static String echo() { return pick(ECHO); }
    public static String hunt() { return pick(HUNT); }

    private static String pick(List<String> pool) {
        return pool.get(RNG.nextInt(pool.size()));
    }
}
