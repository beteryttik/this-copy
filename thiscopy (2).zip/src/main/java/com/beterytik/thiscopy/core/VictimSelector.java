package com.beterytik.thiscopy.core;

import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.Random;
import java.util.UUID;

public class VictimSelector {
    private static final Random RNG = new Random();
    private static UUID lastVictim;

    public static ServerPlayerEntity choose(List<ServerPlayerEntity> players, UUID previous) {
        if (players.size() == 1) {
            lastVictim = players.get(0).getUuid();
            return players.get(0);
        }
        List<ServerPlayerEntity> pool = players;
        if (previous != null && players.size() > 1) {
            pool = players.stream().filter(p -> !p.getUuid().equals(previous)).toList();
        }
        ServerPlayerEntity chosen = pool.get(RNG.nextInt(pool.size()));
        lastVictim = chosen.getUuid();
        return chosen;
    }
}
