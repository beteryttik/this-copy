package com.beterytik.thiscopy.core;

import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;

/** Режиссёр ужаса на ванильных звуках: знакомое, но с «неправильным» питчем. */
public class SoundDirector {
    private static final Random RNG = Random.create();

    public static void playNear(ServerWorld world, BlockPos pos, String soundId, float pitch) {
        if (pos == null) return;
        SoundEvent event = Registries.SOUND_EVENT.get(Identifier.ofVanilla(soundId));
        if (event == null) return;
        world.playSound(null, pos, event, SoundCategory.AMBIENT,
                0.8F, pitch);
    }

    public static void glitched(ServerWorld world, BlockPos pos) {
        float[] pitches = {0.31F, 0.55F, 1.31F, 1.73F};
        playNear(world, pos, "ambient.cave", pitches[RNG.nextInt(pitches.length)]);
    }
}
