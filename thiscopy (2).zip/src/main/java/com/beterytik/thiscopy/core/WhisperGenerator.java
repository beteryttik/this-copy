package com.beterytik.thiscopy.core;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Random;

/** Генератор шёпота: «жвжв… по-о-омни… я слышу дыхание». */
public class WhisperGenerator {
    private static final Random RNG = new Random();
    private static final String[] SYL = {"жв", "мм", "шш", "о-о", "омн", "тьм", "скр", "хх", "жж"};
    private static final String[] WORDS = {"по-о-мни", "не-на-ви-жу", "я-я-я", "слы-шу", "за-то-бой", "о-бог-ни"};

    public void whisperOnce(ServerPlayerEntity p, String mode) {
        String whisper = build();
        p.sendMessage(Text.literal("§8" + whisper + "§r").formatted(Formatting.OBFUSCATED));
    }

    private String build() {
        StringBuilder sb = new StringBuilder();
        int n = 2 + RNG.nextInt(3);
        for (int i = 0; i < n; i++) {
            sb.append(RNG.nextBoolean() ? SYL[RNG.nextInt(SYL.length)] : WORDS[RNG.nextInt(WORDS.length)]);
            if (i < n - 1) sb.append(' ');
        }
        return sb.toString();
    }
}
