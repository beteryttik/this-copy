package com.beterytik.thiscopy.core;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Кольцевой буфер движений жертвы: Она может «отыграть назад» твои шаги. */
public class MovementBuffer {
    public record Sample(double x, double y, double z, float yaw, float pitch) { }

    private static final Map<UUID, Deque<Sample>> BUFFERS = new ConcurrentHashMap<>();
    private static final int CAPACITY = 1200; // 60 секунд при семпле каждые 4 тика
    private static int sampleCounter = 0;

    public static void init(PlayerEntity p) {
        BUFFERS.put(p.getUuid(), new ArrayDeque<>());
    }

    public static void sample(PlayerEntity p) {
        if (p == null) return;
        sampleCounter++;
        if (sampleCounter % 4 != 0) return;
        Deque<Sample> deque = BUFFERS.computeIfAbsent(p.getUuid(), k -> new ArrayDeque<>());
        deque.addLast(new Sample(p.getX(), p.getY(), p.getZ(), p.getYaw(), p.getPitch()));
        while (deque.size() > CAPACITY) deque.removeFirst();
    }

    /** Движение N тиков назад (в семплах: N/4). */
    public static Sample rewind(PlayerEntity p, int ticks) {
        Deque<Sample> deque = BUFFERS.get(p.getUuid());
        if (deque == null || deque.isEmpty()) return null;
        int n = Math.max(1, ticks / 4);
        Sample[] arr = deque.toArray(new Sample[0]);
        int idx = arr.length - 1 - n;
        if (idx < 0) return arr.length > 0 ? arr[0] : null;
        return arr[idx];
    }

    public static void clear(UUID id) {
        BUFFERS.remove(id);
    }
}
