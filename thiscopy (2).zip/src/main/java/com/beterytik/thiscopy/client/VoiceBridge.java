package com.beterytik.thiscopy.client;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;

/** Воспроизведение твоих фраз тебе же — с заниженным питчем. Твой голос, но не твой. */
public class VoiceBridge {
    private static final int RATE = 16000;
    private static final int RING = RATE * 15;
    private static final short[] RING_BUF = new short[RING];
    private static int readPos = 0;

    public static void startEchoThread() {
        Thread t = new Thread(VoiceBridge::loop, "thiscopy-voice");
        t.setDaemon(true);
        t.start();
    }

    private static void loop() {
        try {
            AudioFormat format = new AudioFormat(RATE, 16, 1, true, false);
            SourceDataLine out = (SourceDataLine) AudioSystem.getLine(
                    new DataLine.Info(SourceDataLine.class, format));
            out.open(format, RATE / 2);
            out.start();
            byte[] chunk = new byte[1024];
            boolean voiceEnabled = com.beterytik.thiscopy.ModConfig.VOICE_ENABLED;
            float pitch = com.beterytik.thiscopy.ModConfig.VOICE_PITCH;
            while (true) {
                Thread.sleep(120);
                if (!voiceEnabled) continue;
                if (MicrophoneRecorder.isSpeaking()) continue; // не эхо в прямой речи
                int n = chunk.length / 2;
                for (int i = 0; i < n; i++) {
                    short s = RING_BUF[readPos];
                    readPos = (readPos + 1) % RING;
                    chunk[i * 2] = (byte) (s & 0xFF);
                    chunk[i * 2 + 1] = (byte) (s >> 8);
                }
                out.write(chunk, 0, chunk.length);
            }
        } catch (Exception ignored) { }
    }
}
