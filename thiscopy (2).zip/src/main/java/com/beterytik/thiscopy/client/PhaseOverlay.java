package com.beterytik.thiscopy.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;

public class PhaseOverlay {
    public static int phaseId = 0;
    public static int ticksLeft = 0;

    private static final Identifier[] VIGNETTES = new Identifier[7];

    static {
        for (int i = 1; i <= 6; i++) {
            VIGNETTES[i] = Identifier.of(com.beterytik.thiscopy.ThisCopy.MOD_ID,
                    "textures/gui/phase_" + i + ".png");
        }
    }

    public static void register() {
        HudRenderCallback.EVENT.register(PhaseOverlay::render);
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        if (phaseId <= 0 || phaseId >= VIGNETTES.length) return;
        Identifier id = VIGNETTES[phaseId];
        if (id == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        int pulse = (int) (Math.sin((ticksLeft % 20) / 20.0 * Math.PI * 2) * 40) + 140;
        ctx.fill(0, 0, w, h, (pulse << 24));
        ctx.drawTexture(RenderLayer::getGuiTextured, id, 0, 0, 0, 0, w, h, w, h);
    }
}
