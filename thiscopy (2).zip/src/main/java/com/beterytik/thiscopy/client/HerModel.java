package com.beterytik.thiscopy.client;

import com.beterytik.thiscopy.entity.SheEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;

public class HerModel extends BipedEntityModel<SheEntity> {
    public HerModel(ModelPart root) {
        super(root);
    }
}
