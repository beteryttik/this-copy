package com.beterytik.thiscopy.client;

import com.beterytik.thiscopy.ModRegistry;
import com.beterytik.thiscopy.entity.SheEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.EntityRendererFactory;

public class ThisCopyClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        PhaseOverlay.register();
        EntityRendererRegistry.register(ModRegistry.SHE, HerRenderer::new);
        com.beterytik.thiscopy.net.Payloads.registerClient();
    }
}
