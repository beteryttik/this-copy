package com.beterytik.thiscopy.client;

import javax.sound.sampled.*;
import java.io.ByteArrayOutputStream;
import java.util.concurrent.atomic.AtomicBoolean;

/** Запись микрофона в кольцевой буфер на 15 секунд (16 кГц, моно, 16 бит). */
public class MicrophoneRecorder {
    private static final int RATE = 16000;
    private static final int BUFFER_SECONDS = 15;
    private static final int RING_SAMPLES = RATE * BUFFER_SECONDS;

    private static final short[] RING = new short[RING_SAMPLES];
    private static int writePos = 0;
    private static int speechLevel = 0;
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    private static TargetDataLine line;

    public static synchronized void start() {
        if (RUNNING.get()) return;
        RUNNING.set(true);
        Thread t = new Thread(MicrophoneRecorder::loop, "thiscopy-mic");
        t.setDaemon(true);
        t.start();
    }

    private static void loop() {
        try {
            AudioFormat format = new AudioFormat(RATE, 16, 1, true, false);
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
            line = (TargetDataLine) AudioSystem.getLine(info);
            line.open(format, RATE / 2);
            line.start();
            byte[] chunk = new byte[2048];
            while (RUNNING.get()) {
                int read = line.read(chunk, 0, chunk.length);
                push(chunk, read);
            }
            line.stop();
            line.close();
        } catch (Exception ignored) {
        } finally {
            RUNNING.set(false);
        }
    }

    private static void push(byte[] bytes, int len) {
        int peak = 0;
        for (int i = 0; i + 1 < len; i += 2) {
            short s = (short) ((bytes[i] & 0xFF) | (bytes[i + 1] << 8));
            RING[writePos] = s;
            writePos = (writePos + 1) % RING_SAMPLES;
            int a = Math.abs(s);
            if (a > peak) peak = a;
        }
        speechLevel = peak;
    }

    public static boolean isSpeaking() {
        return speechLevel > 900;
    }

    public static int level() {
        return speechLevel;
    }

    public static synchronized void stop() {
        RUNNING.set(false);
    }
}
