package com.beterytik.thiscopy.client;

import com.beterytik.thiscopy.ThisCopy;
import com.beterytik.thiscopy.entity.SheEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;

public class HerRenderer extends BipedEntityRenderer<SheEntity, HerModel> {
    private static final Identifier[] SKINS = new Identifier[30];

    static {
        for (int i = 0; i < 30; i++) {
            SKINS[i] = Identifier.of(ThisCopy.MOD_ID, "textures/entity/she/she_" + i + ".png");
        }
    }

    public HerRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new HerModel(ctx.getPart(EntityModelLayers.PLAYER)), 0.4F);
    }

    @Override
    public Identifier getTexture(SheEntity entity) {
        int idx = (entity.getWorld().getTimeOfDay() > 0.5 ? 0 : 15)
                + (entity.age % 15);
        return SKINS[idx % SKINS.length];
    }
}
