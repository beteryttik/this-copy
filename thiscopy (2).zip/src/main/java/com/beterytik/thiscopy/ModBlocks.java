package com.beterytik.thiscopy;

import com.beterytik.thiscopy.block.AltarBlock;
import com.beterytik.thiscopy.block.CandleBlock;
import com.beterytik.thiscopy.block.MirrorBlock;
import com.beterytik.thiscopy.block.WhisperStoneBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

public class ModBlocks {
    public static final Block MIRROR = register("mirror",
            new MirrorBlock(net.minecraft.block.AbstractBlock.Settings.copy(Blocks.OBSIDIAN)
                    .strength(5.0F, 1200.0F).luminance(s -> 7).nonOpaque()));
    public static final Block ALTAR = register("altar",
            new AltarBlock(net.minecraft.block.AbstractBlock.Settings.copy(Blocks.STONE_BRICKS)
                    .strength(3.0F, 1200.0F).luminance(s -> 5).nonOpaque()));
    public static final Block WHISPER_STONE = register("whisper_stone",
            new WhisperStoneBlock(net.minecraft.block.AbstractBlock.Settings.copy(Blocks.DEEPSLATE)
                    .strength(4.0F, 1200.0F).luminance(s -> 3)));
    public static final Block CANDLE = register("candle",
            new CandleBlock(net.minecraft.block.AbstractBlock.Settings.copy(Blocks.CANDLE)
                    .strength(0.5F).luminance(s -> 9).nonOpaque()));

    private static Block register(String name, Block block) {
        Identifier id = Identifier.of(ThisCopy.MOD_ID, name);
        Registry.register(Registries.BLOCK, id, block);
        Registry.register(Registries.ITEM, id,
                new BlockItem(block, new Item.Settings()));
        return block;
    }

    public static void register() { }
}
