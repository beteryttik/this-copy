package com.beterytik.thiscopy.block;

import com.beterytik.thiscopy.ModItems;
import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.ending.BanishEnding;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class AltarBlock extends Block {
    public AltarBlock(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos,
                              PlayerEntity player, BlockHitResult hit) {
        if (world instanceof ServerWorld sw) {
            HerManager m = HerManager.get(sw);
            ItemStack held = player.getMainHandStack();
            if (held.isOf(ModItems.MIRROR_SHARD) && m.phase() != null && m.phase().id() == 2) {
                held.decrementUnlessCreative(1, player);
                BanishEnding.perform(m);
                return ActionResult.SUCCESS;
            }
        }
        return ActionResult.PASS;
    }
}
