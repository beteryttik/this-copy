package com.beterytik.thiscopy.block;

import net.minecraft.block.Block;

public class CandleBlock extends Block {
    public CandleBlock(Settings settings) {
        super(settings);
    }
}
