package com.beterytik.thiscopy.block;

import com.beterytik.thiscopy.core.PhraseBank;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class WhisperStoneBlock extends Block {
    public WhisperStoneBlock(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos,
                              PlayerEntity player, BlockHitResult hit) {
        if (!world.isClient) {
            player.sendMessage(Text.literal(PhraseBank.shadow()).formatted(net.minecraft.util.Formatting.DARK_GRAY));
        }
        return ActionResult.SUCCESS;
    }
}
