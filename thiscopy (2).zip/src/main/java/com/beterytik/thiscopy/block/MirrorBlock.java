package com.beterytik.thiscopy.block;

import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.ending.BanishEnding;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

public class MirrorBlock extends Block {
    public MirrorBlock(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos,
                              PlayerEntity player, BlockHitResult hit) {
        if (world instanceof ServerWorld sw && player instanceof ServerPlayerEntity sp) {
            HerManager m = HerManager.get(sw);
            if (m.phase() != null && m.phase().id() == 2 && m.victim() == sp) {
                BanishEnding.perform(m);
                return ActionResult.SUCCESS;
            }
        }
        return ActionResult.PASS;
    }

    @Override
    public boolean emitsRedstonePower(BlockState state) {
        return false;
    }
}
