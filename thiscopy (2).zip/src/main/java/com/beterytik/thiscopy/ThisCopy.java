package com.beterytik.thiscopy;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ThisCopy implements ModInitializer {
    public static final String MOD_ID = "thiscopy";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModConfig.load();
        ModRegistry.register();
        ModBlocks.register();
        ModItems.register();
        Payloads.register();
        ThisCopyCommand.register();
        ServerEvents.register();
        LOGGER.info("[This Copy] She is listening.");
    }
}
