package com.beterytik.thiscopy.item;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class MirrorShardItem extends Item {
    public MirrorShardItem(Settings settings) {
        super(settings);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
}
