package com.beterytik.thiscopy.item;

import net.minecraft.item.Item;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;

import java.util.List;

public class DiaryItem extends Item {
    private static final String[] PAGES = {
            "day.1", "day.2", "day.3", "day.4", "day.5"
    };

    public DiaryItem(Settings settings) {
        super(settings);
    }

    public static String pageFor(int day) {
        return PAGES[MathHelper.clamp(day, 1, PAGES.length) - 1];
    }
}
