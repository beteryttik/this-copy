package com.beterytik.thiscopy.item;

import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.ending.MergeEnding;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;

public class MirrorHeartItem extends Item {
    public MirrorHeartItem(Settings settings) {
        super(settings);
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, net.minecraft.entity.LivingEntity user) {
        if (world instanceof ServerWorld sw && user instanceof ServerPlayerEntity sp) {
            HerManager m = HerManager.get(sw);
            if (m.phase() != null && m.phase().id() == 5) {
                MergeEnding.perform(m);
                stack.decrementUnlessCreative(1, sp);
            }
        }
        return stack;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.thiscopy.mirror_heart.tooltip").formatted(Formatting.DARK_PURPLE));
    }
}
