package com.beterytik.thiscopy;

import java.io.*;
import java.util.Properties;

public class ModConfig {
    public static int PHASE_TICKS = 12000;
    public static int SHADOW_TICKS = 3600;
    public static int MIRROR_TICKS = 4800;
    public static int ECHO_TICKS = 4800;
    public static int GLITCH_TICKS = 3600;
    public static int HUNT_TICKS = 2400;
    public static double TRIGGER_DISTANCE = 24.0;
    public static boolean VOICE_ENABLED = true;
    public static float VOICE_PITCH = 0.72F;
    public static boolean HARD_MODE = false;

    private static File file() {
        return new File("config", "thiscopy.properties");
    }

    public static void load() {
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(file())) {
            p.load(in);
        } catch (IOException ignored) { }
        PHASE_TICKS = intp(p, "phase_ticks", PHASE_TICKS);
        SHADOW_TICKS = intp(p, "shadow_ticks", SHADOW_TICKS);
        MIRROR_TICKS = intp(p, "mirror_ticks", MIRROR_TICKS);
        ECHO_TICKS = intp(p, "echo_ticks", ECHO_TICKS);
        GLITCH_TICKS = intp(p, "glitch_ticks", GLITCH_TICKS);
        HUNT_TICKS = intp(p, "hunt_ticks", HUNT_TICKS);
        VOICE_ENABLED = boolp(p, "voice_enabled", VOICE_ENABLED);
        HARD_MODE = boolp(p, "hard_mode", HARD_MODE);
    }

    private static int intp(Properties p, String k, int def) {
        try { return Integer.parseInt(p.getProperty(k, String.valueOf(def))); }
        catch (NumberFormatException e) { return def; }
    }

    private static boolean boolp(Properties p, String k, boolean def) {
        return Boolean.parseBoolean(p.getProperty(k, String.valueOf(def)));
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("phase_ticks", String.valueOf(PHASE_TICKS));
        p.setProperty("shadow_ticks", String.valueOf(SHADOW_TICKS));
        p.setProperty("mirror_ticks", String.valueOf(MIRROR_TICKS));
        p.setProperty("echo_ticks", String.valueOf(ECHO_TICKS));
        p.setProperty("glitch_ticks", String.valueOf(GLITCH_TICKS));
        p.setProperty("hunt_ticks", String.valueOf(HUNT_TICKS));
        p.setProperty("voice_enabled", String.valueOf(VOICE_ENABLED));
        p.setProperty("hard_mode", String.valueOf(HARD_MODE));
        try (FileOutputStream out = new FileOutputStream(file())) {
            p.store(out, "This Copy config");
        } catch (IOException ignored) { }
    }
}
