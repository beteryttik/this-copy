package com.beterytik.thiscopy.ending;

import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.entity.HerState;
import net.minecraft.util.Formatting;

/** Слияние: зеркальное сердце — она становится союзницей. */
public class MergeEnding implements Ending {
    public static final MergeEnding INSTANCE = new MergeEnding();

    @Override public String id() { return "merge"; }

    public static void perform(HerManager m) {
        HerState s = m.state();
        s.setMerged(true);
        s.setPhase(6); // AllyPhase
        announce(m, "merge", Formatting.LIGHT_PURPLE);
    }
}
