package com.beterytik.thiscopy.ending;

import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.entity.HerState;
import net.minecraft.util.Formatting;

/** Изгнание: зеркало + осколок на алтаре, в фазе Зеркало. */
public class BanishEnding implements Ending {
    public static final BanishEnding INSTANCE = new BanishEnding();

    @Override public String id() { return "banish"; }

    public static void perform(HerManager m) {
        m.entity().ifPresent(e -> e.discard());
        HerState s = m.state();
        s.setBanished(true);
        s.reset();
        announce(m, "banish", Formatting.AQUA);
    }
}
