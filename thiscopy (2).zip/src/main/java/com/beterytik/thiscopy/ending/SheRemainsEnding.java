package com.beterytik.thiscopy.ending;

import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.entity.HerState;
import net.minecraft.util.Formatting;

/** Она остаётся: убьёшь её — вернётся навсегда, сильнее. */
public class SheRemainsEnding implements Ending {
    public static final SheRemainsEnding INSTANCE = new SheRemainsEnding();

    @Override public String id() { return "she_remains"; }

    public static void perform(HerManager m) {
        HerState s = m.state();
        s.setSheRemains(true);
        s.reset();
        s.setSheRemains(true); // флаг не сбрасывается никогда
        announce(m, "she_remains", Formatting.DARK_RED);
    }
}
