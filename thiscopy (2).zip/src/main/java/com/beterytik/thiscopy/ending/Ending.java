package com.beterytik.thiscopy.ending;

import com.beterytik.thiscopy.core.HerManager;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public interface Ending {
    String id();

    static void announce(HerManager m, String key, Formatting color) {
        for (var p : m.world().getPlayers()) {
            p.sendMessage(Text.translatable("ending.thiscopy." + key).formatted(color));
        }
    }
}
