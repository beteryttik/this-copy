package com.beterytik.thiscopy.ending;

import com.beterytik.thiscopy.core.HerManager;
import net.minecraft.util.Formatting;

/** Побег: пережить три охоты — она уходит искать другую цель. */
public class EscapeEnding implements Ending {
    public static final EscapeEnding INSTANCE = new EscapeEnding();

    @Override public String id() { return "escape"; }

    public static void record(HerManager m) {
        HerState s = m.state();
        s.addHuntSurvived();
        s.setPhaseTicks(0);
        if (s.huntsSurvived() >= 3) {
            s.setPhase(1); // вернуться в Тень и забыть жертву
            s.setVictim(null);
            announce(m, "escape", Formatting.GREEN);
        } else {
            announce(m, "hunt_survived", Formatting.YELLOW);
        }
    }
}
