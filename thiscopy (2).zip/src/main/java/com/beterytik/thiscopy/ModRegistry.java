package com.beterytik.thiscopy;

import com.beterytik.thiscopy.entity.SheEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModRegistry {
    public static final EntityType<SheEntity> SHE = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(ThisCopy.MOD_ID, "she"),
            EntityType.Builder.create(SheEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6F, 1.9F)
                    .build()
    );

    public static void register() {
        FabricDefaultAttributeRegistry.register(SHE, MobEntity.createMobAttributes());
    }
}
