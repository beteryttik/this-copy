package com.beterytik.thiscopy;

import com.beterytik.thiscopy.item.DiaryItem;
import com.beterytik.thiscopy.item.MirrorHeartItem;
import com.beterytik.thiscopy.item.MirrorShardItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item MIRROR_SHARD = register("mirror_shard",
            new MirrorShardItem(new Item.Settings().maxCount(16)));
    public static final Item MIRROR_HEART = register("mirror_heart",
            new MirrorHeartItem(new Item.Settings().maxCount(1).fireproof()));
    public static final Item DIARY = register("diary",
            new DiaryItem(new Item.Settings().maxCount(1)));

    private static Item register(String name, Item item) {
        Registry.register(Registries.ITEM, Identifier.of(ThisCopy.MOD_ID, name), item);
        return item;
    }

    public static void register() { }
}
