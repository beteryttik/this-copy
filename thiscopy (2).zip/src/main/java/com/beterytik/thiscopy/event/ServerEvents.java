package com.beterytik.thiscopy.event;

import com.beterytik.thiscopy.command.ThisCopyCommand;
import com.beterytik.thiscopy.core.EchoChat;
import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.core.MovementBuffer;
import com.beterytik.thiscopy.net.Payloads;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.world.ServerWorld;

public class ServerEvents {
    public static void register() {
        EchoChat.registerHook();

        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (world instanceof ServerWorld sw) {
                HerManager.get(sw).tick();
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            MovementBuffer.clear(handler.getPlayer().getUuid());
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, access, env) -> {
            ThisCopyCommand.registerDispatcher(dispatcher);
        });

        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            // прогрев кеша фаз
        });
    }

    public static void sendPhase(ServerWorld world, int phase, int ticksLeft) {
        for (var p : world.getPlayers()) {
            ServerPlayNetworking.send(p, new Payloads.PhasePayload(phase, ticksLeft));
        }
    }
}
