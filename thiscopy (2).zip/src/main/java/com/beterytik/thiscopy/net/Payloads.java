package com.beterytik.thiscopy;

import com.beterytik.thiscopy.client.PhaseOverlay;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public class Payloads {
    public record PhasePayload(int phaseId, int ticksLeft) implements CustomPayload {
        public static final CustomPayload.Id<PhasePayload> ID =
                new CustomPayload.Id<>(Identifier.of(ThisCopy.MOD_ID, "phase"));
        public static final PacketCodec<RegistryByteBuf, PhasePayload> CODEC =
                PacketCodec.tuple(PacketCodecs.VAR_INT, PhasePayload::phaseId,
                                  PacketCodecs.VAR_INT, PhasePayload::ticksLeft, PhasePayload::new);

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    // PacketCodecs reference — see below
    static final class PacketCodecs {
        static net.minecraft.network.codec.PacketCodec<net.minecraft.network.RegistryByteBuf, Integer> VAR_INT =
                net.minecraft.network.codec.PacketCodecs.VAR_INT;
    }

    public static void register() {
        PayloadTypeRegistry.playS2C().register(PhasePayload.ID, PhasePayload.CODEC);
    }

    public static void registerClient() {
        ClientPlayNetworking.registerGlobalReceiver(PhasePayload.ID, (payload, context) -> {
            context.client().execute(() -> {
                PhaseOverlay.phaseId = payload.phaseId();
                PhaseOverlay.ticksLeft = payload.ticksLeft();
            });
        });
    }
}
