package com.beterytik.thiscopy.phase;

import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.core.SoundDirector;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.List;

/** Фаза 4. Глюк: пустые окна тишины, шаги за спиной. */
public class GlitchPhase implements PhaseStrategy {
    @Override public int id() { return 4; }
    @Override public int durationTicks() { return com.beterytik.thiscopy.ModConfig.GLITCH_TICKS; }
    @Override public String title() { return "Glitch"; }

    @Override
    public void tick(HerManager m) {
        List<ServerPlayerEntity> players = m.world().getPlayers();
        if (players.isEmpty()) return;
        int tick = m.worldTicks();
        // окно тишины: на 100 тиков все звуки режиссёра молчат
        boolean silence = (tick % 600) < 100;
        if (silence) return;

        if (tick % 80 == 0) {
            SoundDirector.playNear(m.world(), m.victimPos(), "entity.enderman.stare", 1.6F);
        }
        if (tick % 220 == 0) {
            for (ServerPlayerEntity p : players) {
                m.world().spawnParticles(ParticleTypes.ASH,
                        p.getX(), p.getY(), p.getZ(), 30, 3.0, 1.0, 3.0, 0.01);
            }
        }
        if (tick % 700 == 0 && !players.isEmpty()) {
            PlayerEntity victim = m.victim();
            if (victim != null) {
                victim.sendMessage(Text.literal("<...> не оборачивайся"), true);
            }
        }
    }
}
