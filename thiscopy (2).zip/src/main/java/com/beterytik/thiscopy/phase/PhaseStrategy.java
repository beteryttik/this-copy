package com.beterytik.thiscopy.phase;

import com.beterytik.thiscopy.core.HerManager;

public interface PhaseStrategy {
    int id();
    int durationTicks();
    void tick(HerManager manager);
    String title();
}
