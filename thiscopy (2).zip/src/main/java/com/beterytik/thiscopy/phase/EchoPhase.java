package com.beterytik.thiscopy.phase;

import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.core.SoundDirector;

/** Фаза 3. Эхо: чат возвращает твои слова, но не твои. */
public class EchoPhase implements PhaseStrategy {
    @Override public int id() { return 3; }
    @Override public int durationTicks() { return com.beterytik.thiscopy.ModConfig.ECHO_TICKS; }
    @Override public String title() { return "Echo"; }

    @Override
    public void tick(HerManager m) {
        if (m.worldTicks() % 300 == 0) {
            m.echo().echoOnce();
        }
        if (m.worldTicks() % 250 == 0) {
            SoundDirector.playNear(m.world(), m.victimPos(), "block.note_block.pling", 0.45F);
        }
    }
}
