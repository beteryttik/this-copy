package com.beterytik.thiscopy.phase;

import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.core.SoundDirector;
import com.beterytik.thiscopy.ending.EscapeEnding;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;

/** Фаза 5. Охота: она перестаёт быть копией. */
public class HuntPhase implements PhaseStrategy {
    @Override public int id() { return 5; }
    @Override public int durationTicks() { return com.beterytik.thiscopy.ModConfig.HUNT_TICKS; }
    @Override public String title() { return "Hunt"; }

    @Override
    public void tick(HerManager m) {
        m.entity().ifPresent(e -> e.setInvisible(false));
        if (m.worldTicks() % 40 == 0) {
            SoundDirector.playNear(m.world(), m.victimPos(), "entity.warden.heartbeat", 1.2F);
        }
        if (m.worldTicks() % 200 == 0) {
            ServerPlayerEntity v = m.victim();
            if (v != null) {
                v.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 160, 0, false, false));
            }
        }
        if (m.phaseTicksLeft() <= 0) {
            EscapeEnding.record(m);
        }
    }
}
