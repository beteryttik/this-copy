package com.beterytik.thiscopy.phase;

import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.core.SoundDirector;

/** Фаза 1. Тень: она только выбирает. Свечи гаснут по одной. */
public class ShadowPhase implements PhaseStrategy {
    @Override public int id() { return 1; }
    @Override public int durationTicks() { return com.beterytik.thiscopy.ModConfig.SHADOW_TICKS; }
    @Override public String title() { return "Shadow"; }

    @Override
    public void tick(HerManager m) {
        if (m.worldTicks() % 200 == 0) {
            SoundDirector.playNear(m.world(), m.victimPos(), "ambient.cave", 0.35F);
        }
        if (m.worldTicks() % 600 == 0 && m.victim() != null) {
            m.whisper().whisperOnce(m.victim(), "shadow.whisper");
        }
    }
}
