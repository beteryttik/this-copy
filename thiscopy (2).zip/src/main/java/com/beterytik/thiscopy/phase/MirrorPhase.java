package com.beterytik.thiscopy.phase;

import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.core.SoundDirector;

/** Фаза 2. Зеркало: она копирует движения жертвы с задержкой. */
public class MirrorPhase implements PhaseStrategy {
    @Override public int id() { return 2; }
    @Override public int durationTicks() { return com.beterytik.thiscopy.ModConfig.MIRROR_TICKS; }
    @Override public String title() { return "Mirror"; }

    @Override
    public void tick(HerManager m) {
        if (m.worldTicks() % 100 == 0) {
            SoundDirector.playNear(m.world(), m.victimPos(), "block.glass.place", 0.7F);
        }
        if (m.worldTicks() % 400 == 0 && m.victim() != null) {
            m.entity().ifPresent(e -> e.setInvisible(false));
        }
    }
}
