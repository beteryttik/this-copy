package com.beterytik.thiscopy.phase;

import com.beterytik.thiscopy.core.HerManager;

/** Концовка «Слияние»: она становится союзницей и больше не охотится. */
public class AllyPhase implements PhaseStrategy {
    @Override public int id() { return 6; }
    @Override public int durationTicks() { return Integer.MAX_VALUE; }
    @Override public String title() { return "Ally"; }

    @Override
    public void tick(HerManager m) {
        if (m.worldTicks() % 1200 == 0 && m.victim() != null) {
            m.entity().ifPresent(e -> e.setInvisible(false));
        }
    }
}
