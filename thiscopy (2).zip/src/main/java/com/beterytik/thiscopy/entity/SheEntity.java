package com.beterytik.thiscopy.entity;

import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.core.MovementBuffer;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class SheEntity extends MobEntity {
    private PlayerEntity copyTarget;

    public SheEntity(EntityType<? extends MobEntity> type, World world) {
        super(type, world);
        this.setInvisible(true);
        this.setPersistent();
        this.setSilent(true);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new LookAtEntityGoal(this, PlayerEntity.class, 16.0F));
        this.goalSelector.add(2, new LookAroundGoal(this));
        this.goalSelector.add(3, new CopyGoal());
    }

    public void setCopyTarget(PlayerEntity target) {
        this.copyTarget = target;
    }

    public PlayerEntity getCopyTarget() {
        return copyTarget;
    }

    class CopyGoal extends Goal {
        @Override
        public boolean canStart() {
            return copyTarget != null && copyTarget.isAlive();
        }

        @Override
        public void tick() {
            if (copyTarget == null || copyTarget.getWorld() != getWorld()) return;
            MovementBuffer.Sample s = MovementBuffer.rewind(copyTarget, 40);
            if (s != null) {
                refreshPositionAndAngles(s.x, s.y, s.z, s.yaw, s.pitch);
            } else {
                Vec3d dir = copyTarget.getPos().subtract(getPos());
                double d = dir.horizontalLength();
                if (d > TRIGGER()) {
                    getNavigation().startMovingTo(copyTarget, 1.1);
                }
            }
            getBodyYaw().add(0);
            setYaw(MathHelper.wrapDegrees(copyTarget.getYaw() - getYaw()) + getYaw());
        }
    }

    private double TRIGGER() {
        return com.beterytik.thiscopy.ModConfig.TRIGGER_DISTANCE;
    }

    @Override
    public boolean isInvulnerable() {
        return HerManager.get((ServerWorld) getWorld()).phaseId() != 5;
    }

    @Override
    public boolean canBeLeashedBy(PlayerEntity player) {
        return false;
    }

    @Override
    public boolean cannotDespawn() {
        return true;
    }
}
