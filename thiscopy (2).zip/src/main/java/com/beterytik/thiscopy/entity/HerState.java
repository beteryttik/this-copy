package com.beterytik.thiscopy.entity;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;

import java.util.UUID;

public class HerState extends PersistentState {
    private UUID victim;
    private int phaseId = 0;
    private int phaseTicks = 0;
    private int huntsSurvived = 0;
    private boolean banished = false;
    private boolean merged = false;
    private boolean sheRemains = false;

    public static final Type<HerState> TYPE = new Type<>(
            HerState::new, HerState::fromNbt, null);

    public HerState() { }

    public static HerState fromNbt(NbtCompound nbt) {
        HerState s = new HerState();
        if (nbt.containsUuid("victim")) s.victim = nbt.getUuid("victim");
        s.phaseId = nbt.getInt("phaseId");
        s.phaseTicks = nbt.getInt("phaseTicks");
        s.huntsSurvived = nbt.getInt("huntsSurvived");
        s.banished = nbt.getBoolean("banished");
        s.merged = nbt.getBoolean("merged");
        s.sheRemains = nbt.getBoolean("sheRemains");
        return s;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        if (victim != null) nbt.putUuid("victim", victim);
        nbt.putInt("phaseId", phaseId);
        nbt.putInt("phaseTicks", phaseTicks);
        nbt.putInt("huntsSurvived", huntsSurvived);
        nbt.putBoolean("banished", banished);
        nbt.putBoolean("merged", merged);
        nbt.putBoolean("sheRemains", sheRemains);
        return nbt;
    }

    public static HerState get(ServerWorld world) {
        return world.getPersistentStateManager().getOrCreate(TYPE, ThisCopy.MOD_ID);
    }

    public UUID victim() { return victim; }
    public void setVictim(UUID u) { this.victim = u; }
    public int phaseId() { return phaseId; }
    public void setPhaseId(int id) { this.phaseId = id; }
    public int phaseTicks() { return phaseTicks; }
    public void setPhaseTicks(int t) { this.phaseTicks = t; }
    public int huntsSurvived() { return huntsSurvived; }
    public void addHuntSurvived() { this.huntsSurvived++; }
    public boolean banished() { return banished; }
    public void setBanished(boolean b) { this.banished = b; }
    public boolean merged() { return merged; }
    public void setMerged(boolean b) { this.merged = b; }
    public boolean sheRemains() { return sheRemains; }
    public void setSheRemains(boolean b) { this.sheRemains = b; }

    public void reset() {
        victim = null;
        phaseId = 0;
        phaseTicks = 0;
        huntsSurvived = 0;
        banished = false;
        merged = false;
        sheRemains = false;
        markDirty();
    }
}
