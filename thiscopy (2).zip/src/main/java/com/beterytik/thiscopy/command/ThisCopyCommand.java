package com.beterytik.thiscopy.command;

import com.beterytik.thiscopy.core.HerManager;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

public class ThisCopyCommand {
    public static void register() {
        // вызывается из ServerLifecycleEvents через CommandRegistrationCallback
    }

    public static void registerDispatcher(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("thiscopy")
                .requires(src -> src.hasPermissionLevel(2))
                .then(CommandManager.literal("start").executes(ctx -> {
                    ServerWorld w = ctx.getSource().getWorld();
                    HerManager.get(w).selectVictimIfNeeded();
                    return 1;
                }))
                .then(CommandManager.literal("stop").executes(ctx -> {
                    ServerWorld w = ctx.getSource().getWorld();
                    HerManager.get(w).state().reset();
                    ctx.getSource().sendFeedback(() -> Text.literal("She forgot."), false);
                    return 1;
                }))
                .then(CommandManager.literal("phase").then(CommandManager.argument("id", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 6))
                        .executes(ctx -> {
                            int id = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "id");
                            ServerWorld w = ctx.getSource().getWorld();
                            HerManager.get(w).setPhase(id);
                            return 1;
                        }))));
    }
}
