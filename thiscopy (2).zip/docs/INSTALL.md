# Установка

1. Fabric Loader 0.20.0+, Minecraft 1.21.11
2. Fabric API 0.141.2+1.21.11
3. thiscopy.jar → mods
4. (опц.) Simple Voice Chat

## Сборка из исходников
JDK 21, `gradle build`, jar в `build/libs/`.
