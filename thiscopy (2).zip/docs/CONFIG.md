# Конфиг `config/thiscopy.properties`

```
phase_ticks=12000
shadow_ticks=3600
mirror_ticks=4800
echo_ticks=4800
glitch_ticks=3600
hunt_ticks=2400
voice_enabled=true
hard_mode=false
```
