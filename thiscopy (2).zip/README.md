# This Copy

**Fabric 1.21.11.** Она смотрит. Она повторяет. Она помнит твой голос.

## Быстрый старт
1. Поставь Fabric Loader 0.20.0+ и Fabric API.
2. (Опционально) Simple Voice Chat — для голосовых фаз.
3. Ночью она выберет жертву сам. Пять фаз. Четыре концовки.

## Сборка
```bash
gradle build
```
или загрузи репозиторий на GitHub — workflow соберёт jar сам (Actions → Artifacts).
