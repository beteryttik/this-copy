package com.beterytik.thiscopy.ending;

import com.beterytik.thiscopy.core.HerManager;
import net.minecraft.server.MinecraftServer;

public class EscapeEnding {
    public static void run(HerManager m, MinecraftServer server) {
        m.phaseId = HerManager.PHASE_IDLE;
        m.phaseTicks = 0;
        m.broadcast(server, "[ThisCopy] You survived another hunt.");
        m.broadcast(server, "[ThisCopy] But she is still out there.");
        if (m.victim != null) {
            var v = server.getPlayerManager().getPlayer(m.victim);
            if (v != null) m.clearDarkness(v);
        }
    }
}
