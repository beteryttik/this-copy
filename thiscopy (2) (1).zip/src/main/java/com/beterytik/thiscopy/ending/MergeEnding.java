package com.beterytik.thiscopy.ending;

import com.beterytik.thiscopy.core.HerManager;
import net.minecraft.server.MinecraftServer;

public class MergeEnding {
    public static void run(HerManager m, MinecraftServer server) {
        m.phaseId = HerManager.PHASE_MERGED;
        m.phaseTicks = 0;
        m.merged = true;
        m.broadcast(server, "[ThisCopy] She has become part of you.");
        m.broadcast(server, "[ThisCopy] The hunt is over. You are her now.");
    }
}
