package com.beterytik.thiscopy.ending;

import com.beterytik.thiscopy.core.HerManager;
import net.minecraft.server.MinecraftServer;

public class SheRemainsEnding {
    public static void run(HerManager m, MinecraftServer server) {
        m.sheRemains = true;
        m.phaseId = HerManager.PHASE_IDLE;
        m.phaseTicks = 0;
        m.broadcast(server, "[ThisCopy] She remained.");
        m.broadcast(server, "[ThisCopy] She is watching from the other side.");
        if (m.victim != null) {
            var v = server.getPlayerManager().getPlayer(m.victim);
            if (v != null) m.clearDarkness(v);
        }
        m.victim = null;
    }
}
