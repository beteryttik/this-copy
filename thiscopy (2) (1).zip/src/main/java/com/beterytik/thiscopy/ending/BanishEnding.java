package com.beterytik.thiscopy.ending;

import com.beterytik.thiscopy.core.HerManager;
import net.minecraft.server.MinecraftServer;

public class BanishEnding {
    public static void run(HerManager m, MinecraftServer server) {
        m.banished = true;
        m.phaseId = HerManager.PHASE_IDLE;
        m.phaseTicks = 0;
        m.broadcast(server, "[ThisCopy] The mirror swallowed her.");
        m.broadcast(server, "[ThisCopy] She is banished. For now.");
        if (m.victim != null) {
            var v = server.getPlayerManager().getPlayer(m.victim);
            if (v != null) m.clearDarkness(v);
        }
        m.victim = null;
    }
}
