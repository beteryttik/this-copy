package com.beterytik.thiscopy.command;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.ending.SheRemainsEnding;

public class ThisCopyCommand {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            registerCommands(dispatcher);
        });
    }

    private static void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("thiscopy")
            .then(CommandManager.literal("start")
                .requires(src -> src.hasPermissionLevel(2))
                .executes(ctx -> {
                    ServerCommandSource src = ctx.getSource();
                    ServerPlayerEntity p = src.getPlayerOrThrow();
                    HerManager m = HerManager.get();
                    if (m.isHunting()) {
                        src.sendMessage(Text.literal("[ThisCopy] The hunt is already on.").formatted(Formatting.RED), false);
                        return 0;
                    }
                    m.startHunt(p);
                    return 1;
                }))
            .then(CommandManager.literal("status")
                .executes(ctx -> {
                    ServerCommandSource src = ctx.getSource();
                    HerManager m = HerManager.get();
                    String status = "phase: " + phaseName(m.phaseId)
                        + " | hunts survived: " + m.huntsSurvived
                        + " | banished: " + m.banished
                        + " | merged: " + m.merged
                        + " | she remains: " + m.sheRemains;
                    src.sendMessage(Text.literal("[ThisCopy] " + status).formatted(Formatting.GRAY), false);
                    return 1;
                }))
            .then(CommandManager.literal("end")
                .requires(src -> src.hasPermissionLevel(2))
                .executes(ctx -> {
                    ServerCommandSource src = ctx.getSource();
                    HerManager m = HerManager.get();
                    if (!m.isHunting()) {
                        src.sendMessage(Text.literal("[ThisCopy] Nothing to end.").formatted(Formatting.RED), false);
                        return 0;
                    }
                    SheRemainsEnding.run(m, ctx.getSource().getServer());
                    return 1;
                })));
    }

    private static String phaseName(int id) {
        return switch (id) {
            case HerManager.PHASE_IDLE -> "idle";
            case HerManager.PHASE_SHADOW -> "shadow";
            case HerManager.PHASE_WHISPER -> "whisper";
            case HerManager.PHASE_ECHO -> "echo";
            case HerManager.PHASE_HUNT -> "hunt";
            case HerManager.PHASE_SILENCE -> "silence";
            case HerManager.PHASE_MERGED -> "merged";
            default -> "unknown";
        };
    }
}
