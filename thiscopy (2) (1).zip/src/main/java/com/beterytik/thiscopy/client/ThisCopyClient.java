package com.beterytik.thiscopy.client;

import net.fabricmc.api.ClientModInitializer;

public class ThisCopyClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Visuals come next iteration.
    }
}
