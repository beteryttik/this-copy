package com.beterytik.thiscopy.item;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.ending.BanishEnding;

import java.util.List;

public class MirrorHeartItem extends Item {

    public MirrorHeartItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient()) {
            HerManager m = HerManager.get();
            if (m.isHunting()) {
                BanishEnding.run(m, user.getServer());
                stack.decrementUnlessCreative(1, user);
            } else {
                user.sendMessage(Text.literal("[ThisCopy] Nothing to banish.").formatted(Formatting.RED), false);
            }
        }
        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public void appendTooltip(ItemStack stack, Item.TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal("Shows her true face.").formatted(Formatting.DARK_PURPLE));
        tooltip.add(Text.literal("Right-click to banish her.").formatted(Formatting.GRAY));
    }
}
