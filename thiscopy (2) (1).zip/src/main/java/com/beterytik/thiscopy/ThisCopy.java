package com.beterytik.thiscopy;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ThisCopy implements ModInitializer {
    public static final String MOD_ID = "thiscopy";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModRegistry.register();
        HerManager.init();
        ThisCopyCommand.register();
        ServerEvents.register();
        LOGGER.info("[ThisCopy] She is here.");
    }
}
