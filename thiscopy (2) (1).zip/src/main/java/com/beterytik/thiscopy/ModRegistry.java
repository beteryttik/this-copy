package com.beterytik.thiscopy;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import com.beterytik.thiscopy.item.MirrorHeartItem;
import com.beterytik.thiscopy.block.WhisperStoneBlock;

public class ModRegistry {
    public static final Item MIRROR_HEART = Registry.register(Registries.ITEM,
        Identifier.of(ThisCopy.MOD_ID, "mirror_heart"),
        new MirrorHeartItem(new Item.Settings()));

    public static final Block WHISPER_STONE = Registry.register(Registries.BLOCK,
        Identifier.of(ThisCopy.MOD_ID, "whisper_stone"),
        new WhisperStoneBlock(AbstractBlock.Settings.create().strength(1.5f, 6.0f)));

    public static void register() {
        // Registration happens through static field initialization above.
    }
}
