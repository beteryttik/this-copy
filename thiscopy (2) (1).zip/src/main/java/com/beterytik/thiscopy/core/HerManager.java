package com.beterytik.thiscopy.core;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import java.util.*;

public class HerManager {
    private static HerManager instance;

    public static final int PHASE_IDLE = 0;
    public static final int PHASE_SHADOW = 1;
    public static final int PHASE_WHISPER = 2;
    public static final int PHASE_ECHO = 3;
    public static final int PHASE_HUNT = 4;
    public static final int PHASE_SILENCE = 5;
    public static final int PHASE_MERGED = 6;

    public int phaseId = PHASE_IDLE;
    public int phaseTicks = 0;
    public int huntsSurvived = 0;
    public boolean banished = false;
    public boolean merged = false;
    public boolean sheRemains = false;
    public UUID victim = null;
    public long worldTicks = 0;

    private final Map<UUID, Boolean> huntedOnce = new HashMap<>();

    public static void init() {
        instance = new HerManager();
    }

    public static HerManager get() {
        if (instance == null) init();
        return instance;
    }

    public HerState state() {
        HerState s = new HerState();
        s.phaseId = phaseId;
        s.phaseTicks = phaseTicks;
        s.huntsSurvived = huntsSurvived;
        s.banished = banished;
        s.merged = merged;
        s.sheRemains = sheRemains;
        s.victim = victim;
        return s;
    }

    public boolean isHunting() {
        return phaseId >= PHASE_SHADOW && phaseId < PHASE_MERGED;
    }

    public boolean isVictim(UUID id) {
        return id != null && id.equals(victim);
    }

    public void startHunt(ServerPlayerEntity target) {
        this.victim = target.getUuid();
        this.phaseId = PHASE_SHADOW;
        this.phaseTicks = 0;
        this.banished = false;
        this.merged = false;
        this.sheRemains = false;
        huntedOnce.put(this.victim, true);
        broadcast(target.getServer(), "[ThisCopy] ...");
        broadcast(target.getServer(), "[ThisCopy] You are being watched.");
    }

    public void endHunt(MinecraftServer server) {
        if (victim == null) return;
        ServerPlayerEntity p = server.getPlayerManager().getPlayer(victim);
        if (p != null) {
            p.sendMessage(Text.literal("[ThisCopy] The hunt is over. For now.").formatted(Formatting.GRAY), false);
        }
        this.victim = null;
        this.phaseId = PHASE_IDLE;
        this.phaseTicks = 0;
    }

    public void tick(MinecraftServer server) {
        worldTicks++;
        if (phaseId == PHASE_IDLE || phaseId == PHASE_MERGED) return;
        phaseTicks++;

        switch (phaseId) {
            case PHASE_SHADOW -> {
                if (phaseTicks % 600 == 0) broadcast(server, PhraseBank.shadow());
                if (phaseTicks > 1200) advancePhase(server);
            }
            case PHASE_WHISPER -> {
                if (phaseTicks % 400 == 0) broadcast(server, PhraseBank.whisper());
                if (phaseTicks > 1200) advancePhase(server);
            }
            case PHASE_ECHO -> {
                if (phaseTicks % 600 == 0) broadcast(server, PhraseBank.echo());
                if (phaseTicks > 1200) advancePhase(server);
            }
            case PHASE_HUNT -> {
                if (phaseTicks % 100 == 0) {
                    ServerPlayerEntity v = victim == null ? null : server.getPlayerManager().getPlayer(victim);
                    if (v != null) {
                        v.sendMessage(Text.literal("[ThisCopy] She is watching.").formatted(Formatting.DARK_RED), true);
                        applyDarkness(v);
                    }
                }
                if (phaseTicks > 2400) advancePhase(server);
            }
            case PHASE_SILENCE -> {
                if (phaseTicks > 1200) {
                    huntsSurvived++;
                    if (huntsSurvived >= 3) {
                        MergeEnding.run(this, server);
                    } else {
                        endHunt(server);
                        broadcast(server, "[ThisCopy] The silence lifts. For now.");
                    }
                }
            }
            default -> { }
        }
    }

    private void advancePhase(MinecraftServer server) {
        phaseTicks = 0;
        if (phaseId == PHASE_SHADOW) {
            phaseId = PHASE_WHISPER;
        } else if (phaseId == PHASE_WHISPER) {
            phaseId = PHASE_ECHO;
        } else if (phaseId == PHASE_ECHO) {
            phaseId = PHASE_HUNT;
            broadcast(server, "[ThisCopy] She is watching.");
        } else if (phaseId == PHASE_HUNT) {
            phaseId = PHASE_SILENCE;
            broadcast(server, "[ThisCopy] Silence.");
        }
    }

    private void applyDarkness(ServerPlayerEntity p) {
        try {
            p.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(
                net.minecraft.entity.effect.StatusEffects.DARKNESS, 200, 0, false, false, false));
        } catch (Exception ignored) {}
    }

    public void clearDarkness(ServerPlayerEntity p) {
        try {
            p.removeStatusEffect(net.minecraft.entity.effect.StatusEffects.DARKNESS);
        } catch (Exception ignored) {}
    }

    public void broadcast(MinecraftServer server, String text) {
        if (server == null) return;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            p.sendMessage(Text.literal(text), false);
        }
    }
}
