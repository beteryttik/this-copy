package com.beterytik.thiscopy.core;

import java.util.Random;

public class PhraseBank {
    private static final Random R = new Random();

    public static String shadow() {
        String[] s = {
            "[ThisCopy] ...",
            "[ThisCopy] something moves behind you",
            "[ThisCopy] you are not alone",
            "[ThisCopy] don't turn around",
            "[ThisCopy] she is close",
            "[ThisCopy] stop looking for her"
        };
        return s[R.nextInt(s.length)];
    }

    public static String whisper() {
        String[] s = {
            "[ThisCopy] stop copying me",
            "[ThisCopy] you were never you",
            "[ThisCopy] look behind",
            "[ThisCopy] she knows your name",
            "[ThisCopy] do you feel it?",
            "[ThisCopy] the walls are thin here"
        };
        return s[R.nextInt(s.length)];
    }

    public static String echo() {
        String[] s = {
            "[ThisCopy] ...hello?",
            "[ThisCopy] i am still here",
            "[ThisCopy] you forgot me",
            "[ThisCopy] don't leave",
            "[ThisCopy] we can be together",
            "[ThisCopy] i am you"
        };
        return s[R.nextInt(s.length)];
    }
}
