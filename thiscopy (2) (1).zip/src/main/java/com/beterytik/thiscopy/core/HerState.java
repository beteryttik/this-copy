package com.beterytik.thiscopy.core;

import java.util.UUID;

public class HerState {
    public int phaseId;
    public int phaseTicks;
    public int huntsSurvived;
    public boolean banished;
    public boolean merged;
    public boolean sheRemains;
    public UUID victim;
}
