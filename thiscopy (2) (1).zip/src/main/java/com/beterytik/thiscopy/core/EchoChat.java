package com.beterytik.thiscopy.core;

import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import java.util.Random;

public class EchoChat {
    private static final Random R = new Random();

    public static void register() {
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            HerManager m = HerManager.get();
            if (!m.isHunting()) return;
            if (m.phaseId < HerManager.PHASE_ECHO) return;

            String raw = message.getContent().getString();
            if (raw == null || raw.isEmpty()) return;
            if (R.nextInt(100) > 30) return;

            m.broadcast(sender.getServer(), "[ThisCopy] " + raw);
        });
    }
}
