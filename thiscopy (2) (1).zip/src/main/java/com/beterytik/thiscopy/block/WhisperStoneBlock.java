package com.beterytik.thiscopy.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import com.beterytik.thiscopy.core.PhraseBank;

import java.util.List;

public class WhisperStoneBlock extends Block {

    public WhisperStoneBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected ItemActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!world.isClient()) {
            player.sendMessage(Text.literal(PhraseBank.whisper()).formatted(Formatting.DARK_GRAY), false);
        }
        return ItemActionResult.SUCCESS;
    }

    @Override
    public void appendTooltip(ItemStack stack, Item.TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal("It hums when you touch it.").formatted(Formatting.DARK_GRAY));
    }
}
