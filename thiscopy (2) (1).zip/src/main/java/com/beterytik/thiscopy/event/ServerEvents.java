package com.beterytik.thiscopy.event;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import com.beterytik.thiscopy.core.HerManager;
import com.beterytik.thiscopy.core.EchoChat;
import com.beterytik.thiscopy.ending.SheRemainsEnding;

public class ServerEvents {

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            HerManager.get().tick(server);
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            HerManager m = HerManager.get();
            if (m.isHunting() && handler.getPlayer() != null && m.isVictim(handler.getPlayer().getUuid())) {
                SheRemainsEnding.run(m, server);
            }
        });

        EchoChat.register();
    }
}
